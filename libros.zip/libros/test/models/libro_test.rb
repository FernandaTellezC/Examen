require 'test_helper'

class LibroTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
