class Libro < ApplicationRecord
  validates :titulo, :presence => true, length: {minimum:8}, :uniqueness => true
  validates :autor, :presence => true, length: {minimum:8}
  validates :editorial, :presence => true, length: {minimum:8}
  validates :num_pag, :presence => true, length: {minimum:1}
end
