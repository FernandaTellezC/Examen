class LibrosController < ApplicationController
  def index
    @libros = Libro.all
  end
  def show
    @libros = Libro.find(params[:id])
  end
  def new
    @libros = Libro.new
  end
  def edit
    @libros = Libro.find(params[:id])
  end
   def update
    @libros = Libro.find(params[:id])
    if @libros.update(libro_params)
      redirect_to @libros
    else
      render :edit
    end
  end
  def create
    @libros = Libro.new(libro_params)
      if @libros.save
        redirect_to @libros
      else
        render :new
      end
  end
  private
  def libro_params
    params.require(:libro).permit(:titulo,:autor,:editorial,:num_pag)
  end
end 
